/*
 * 
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is Server side of code of block chain, It uses SOAP . The client makes a SOAP request to block chain API on server
 * The transaction data is signed using RSA keys, SHA-256 has been used for hashing the data
 * the client can only view, verify, add the block in a block chain
 */
package com.blockchain;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "BlockChainService")
public class BlockChainService {

    static ArrayList<Block> blocks ;
    static String chainHash;

    
    
    // to be called only once- on first execution
    static{
        blocks = new ArrayList();
        chainHash = "";
        Block genesis = new Block(0, new Timestamp(System.currentTimeMillis()) ,"Genesis",2);
        genesis.setPreviousHash("");
        
        String hash = genesis.proofOfWork(genesis.getDifficulty());
       
        chainHash = hash;//setting chain hash
       
        blocks.add(genesis); //adding genesis block
    }
    
    // method to add the block to block chain
    @WebMethod(operationName = "addBlock")
    public Boolean addBlock(@WebParam(name = "difficulty") int difficulty, @WebParam(name = "data") String data) throws NoSuchAlgorithmException {
        
        
        String [] dataArray = data.split("#");
        String blockData = dataArray[0]; // Fetching data
        
        
        BigInteger signature = new BigInteger(dataArray[1]); // fetching signature
        
        // decrypting 
        BigInteger e = new BigInteger("65537");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        BigInteger decrypt = signature.modPow(e, n); 
        
        
        // hashing the data using SHA-256
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        byte[] digest = m.digest(blockData.getBytes(StandardCharsets.UTF_8));
        
        
        
        // Adding 0 in the most significant byte
        byte [] digest1 = new byte[digest.length+1];
        digest1[0]=0;
        
        int i=1;
        for(byte b:digest){
            digest1[i]=b;
            i++;
        }
        
         BigInteger bigIntegerData = new BigInteger(digest1);
         
         // checking if the signature is correct
         if(bigIntegerData.equals(decrypt)){
                    int index = blocks.size();

               Block newBlock = new Block((index),new Timestamp(System.currentTimeMillis()), data,difficulty);
               newBlock.setPreviousHash(chainHash);
               String hash = newBlock.proofOfWork(newBlock.getDifficulty());
               chainHash = hash;//setting chain hash
               blocks.add(newBlock); //adding new block
         }else{
             return false;
         }
        
     return true;
    }

    
    // checking if the chain is valid
    @WebMethod(operationName = "isChainValid")
    public Boolean isChainValid() throws NoSuchAlgorithmException {
         if(blocks.size()==1){
            
            int difficulty = blocks.get(0).getDifficulty();
            String hash = blocks.get(0).calculateHash();
            char c ='0';
            String diff="";
            int i=0;
            while(i<difficulty){
                
                diff = diff+c;
                i++;
            }
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking chain hash
                if(hash.equals(chainHash)){
                    return true;
            }
            }
            
            // index will be 0 as only one block
            System.out.println("Improper hash on node "+ 0 +" Does not begin with "+difficulty);
            return false;
            
        }
        else{
            int flag=0;
            int corruptedIndex =0;
            for(int i=0;i<blocks.size()-1;i++){
                Block b = blocks.get(i);
                String hash = b.calculateHash();
                int difficulty = b.getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
            
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking previous hash of next block
                String nextPrevHash = blocks.get(i+1).previousHash;
                    if(hash.equals(nextPrevHash)){
                    
                }
                    else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
                    }
            }else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
            }
                    
                
            }
           if(flag==1){
                       
               return false;
           } else{
               
               // for the last block
               int difficulty = blocks.get(blocks.size()-1).getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
               // checking for last block
               String lastHash = blocks.get(blocks.size()-1).calculateHash();
               if(lastHash.equals(chainHash)){
                
                
            
            //Checking number of leading number of zeroes
                    if(lastHash.substring(0, difficulty).equals(diff)){
                        return true;
                    }
                    else{
                        System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+diff);
                        return false;
                    }
                   
                }
               else{
                   System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+ diff);
                   return false;
               }
              
           }
        }
    }
    
    // to display block chain as json string format
    @WebMethod(operationName = "jsonToString")
    public String jsonToString() {
        StringBuilder result = new StringBuilder();
       String NEW_LINE = System.getProperty("line.separator");
       result.append("{\"chain\" :" + "[ {");
       
       // calling to string for every block
       for(Block b: blocks){
            result.append(b.toString());
            result.append(","+ NEW_LINE);
       }
       result.append("],\"chainHash\":\""+chainHash+"\"}");
       return result.toString();
    }

    
}
