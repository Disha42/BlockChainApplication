package com.blockchain;

/*
 * This class represents a simple Block
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is being used in BlockChain
 */

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;

        


/**
 *
 * 
 */
public class Block {
    private int index;
    private Timestamp timestamp;
    private String data;
    private int difficulty;
    public String previousHash;
    public BigInteger nonce = new BigInteger("0");
    
    
    
    public static void main(String args[]){
   
       
        System.out.println("1");
        java.sql.Timestamp t = java.sql.Timestamp.valueOf(LocalDateTime.MIN);
        Block b = new Block(0,t,"Testing",6);
       
        System.out.println("2");
        b.setPreviousHash("previous");
        System.out.println("3");
        b.nonce = new BigInteger("0");
       
        System.out.println("4");
       
       
        System.out.println(b.toString());
       
               System.out.println("5");
              
        String data = b.proofOfWork(6);
       
               System.out.println("6");
        //b.toString();
        System.out.println("hash= "+data);
       
              System.out.println(b.nonce);
   

    }
    
    
    public Block(int index, Timestamp timestamp, String data, int difficulty){
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
        
        previousHash ="";
        
    }
    
//    public static void main(String[] args){
//        java.sql.Timestamp t = java.sql.Timestamp.valueOf(LocalDateTime.MIN);
//        Block b = new Block(0,t,"Testing",5);
//        b.setPreviousHash("previous");
//        b.nonce = new BigInteger("0");
//        System.out.println(b.toString());
//        String data = b.proofOfWork(5);
//        //b.toString();
//        System.out.println("hash= "+data);
//        System.out.println("nonce= "+b.nonce);
//    }
    
    //getters and setters
    public int getDifficulty(){
        return difficulty;
    }
    
    public void setDifficulty(int difficulty){
        this.difficulty = difficulty;
    } 
    
    public void setPreviousHash(String previousHash){
        this.previousHash = previousHash;
    }
    
    public String getPreviousHash(){
        return previousHash;
    }
    
    public int getIndex(){
        return index;
    }
    
    public void setIndex(int index){
        this.index = index;
    }
    
    public void setTimestamp(Timestamp timestamp){
        this.timestamp = timestamp;
    }
    
    public Timestamp getTimestamp(){
        return timestamp;
    }
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    @Override
    // Represting Block object as String
    public String toString(){
    
        //Reference: http://www.javapractices.com/topic/TopicAction.do?Id=55
    StringBuilder result = new StringBuilder();
    
    

    result.append( "{");
    result.append(" \"index\":\"" + this.index +"\",");
    result.append(" \"timestamp\": \"" + this.timestamp +"\",");
    result.append(" \"Tx\":\"" + this.data +"\",");
    result.append(" \"previousHash\":\" " + this.previousHash +"\",");
    result.append(" \"Nonce\": \"" + this.nonce +"\"");
    result.append(" \"difficulty\":\"" + this.difficulty +"\"");
    result.append("}");

    return result.toString();
        
    }
    
    // Computing  hash
    public String calculateHash() throws NoSuchAlgorithmException{
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        String text =  index + timestamp.toString() +data + previousHash + nonce + difficulty;
        byte[] digest = m.digest(text.getBytes(StandardCharsets.UTF_8));
        
        String hexBinary = DatatypeConverter.printHexBinary(digest);
        return hexBinary;
    }
    
    //
    public String proofOfWork(int difficulty){
        
        try {
            
            char c ='0';
            String diff="";
            int i=0;
            while(i<difficulty){
                
                diff = diff+c;
                i++;
            }
           
            while(true){
            
            String hashValue = calculateHash();
            if(hashValue.substring(0, difficulty).equals(diff)){
               return  hashValue;
            }
            else{
                nonce = nonce.add(BigInteger.ONE);
                
                }
            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Block.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }    
    
}
