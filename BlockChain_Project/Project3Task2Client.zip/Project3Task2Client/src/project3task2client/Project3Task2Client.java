/*
 * 
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is Client side of code of block chain, It uses SOAP . The client makes a SOAP request to block chain API on server
 * The transaction data is signed using RSA keys, SHA-256 has been used for hashing the data
 * the client can only view, verify, add the block in a block chain
 * The data is sent in xml format from client to server
 */
package project3task2client;

import com.dnathani.NoSuchAlgorithmException_Exception;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 *
 * @author disna
 */
public class Project3Task2Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchAlgorithmException_Exception {
         Scanner sc = new Scanner(System.in);
     
     int input = 0;
     int countBlock = 1;
     do{
    
     System.out.println("Menu for Block Chain:");
     System.out.println("1. Add a transaction to the blockchain.");
     System.out.println("2. Verify the blockchain.");
     System.out.println("3. View the blockchain.");
     System.out.println("4. Exit.");
     input =sc.nextInt();
     if(input==1){
        System.out.println("Enter difficulty");
        int difficulty = sc.nextInt();
        
        sc.nextLine();
        System.out.println("Enter Transaction");
        String data = sc.nextLine();
        
        Long startTime = System.currentTimeMillis();
        
        // encrypting using SHA-256
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        byte[] digest = m.digest(data.getBytes(StandardCharsets.UTF_8));
       
        
        byte [] digest1 = new byte[digest.length+1];
        digest1[0]=0;
        
        int i=1;
        for(byte b:digest){
            digest1[i]=b;
            i++;
        }
        
        BigInteger bigIntegerData = new BigInteger(digest1);
        //signing // change d and n from notes
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
                        
        BigInteger encryptedData = bigIntegerData.modPow(d, n);
        
        String xmlString = "<data><query>1" +
                            "</query>" +
                            "<encrypteddata>"+(data+"#"+encryptedData)+"" +
                            "</encrypteddata>" +
                            "<difficulty>"+difficulty +
                            "</difficulty></data>";
        String add = operation(xmlString);
         
        if(add.equals("true")){
        Long stopTime = System.currentTimeMillis();
        
        System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + "milliseconds");
        }else{// if signature is wrong
            System.out.println("Wrong signature provided");
        }
        
         
     }
     
     else if(input==2){
         System.out.println("Verifying");
         String xmlString = "<data><query>2" +
                            "</query></data>";
         Long startTime = System.currentTimeMillis();
         System.out.println("Chain Verification:"+operation(xmlString));
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + "milliseconds");
     }
     
     else if(input==3){
          Long startTime = System.currentTimeMillis();
         System.out.println("View the block chain");
          String xmlString = "<data><query>3" +
                            "</query></data>";
         Long stopTime = System.currentTimeMillis();
         System.out.println(operation(xmlString));
        
     }
     
     }while(input!=4);
    }

    private static String operation(java.lang.String xmlString) throws NoSuchAlgorithmException_Exception {
        com.dnathani.BlockChainXML_Service service = new com.dnathani.BlockChainXML_Service();
        com.dnathani.BlockChainXML port = service.getBlockChainXMLPort();
        return port.operation(xmlString);
    }
    
}
