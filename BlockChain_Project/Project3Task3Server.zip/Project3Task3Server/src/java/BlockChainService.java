/*
 * 
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is HTTP servlet. It uses REST architecture. The client makes a HTTP request to block chain API on server
 * The transaction data is signed using RSA keys, SHA-256 has been used for hashing the data
 * the client can only view, verify, add the block in a block chain
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(name = "BlockChainService" , urlPatterns = {"/BlockChainService/*"})
public class BlockChainService extends HttpServlet {

   static ArrayList<Block> blocks ;
   static String chainHash;
   
   
    // using init to initialize array list and chain hash
    @Override
    public void init() {
        blocks = new ArrayList();
        chainHash = "";
        
        // adding genesis
        Block genesis = new Block(0, new Timestamp(System.currentTimeMillis()) ,"Genesis",2);
        genesis.setPreviousHash("");
        
        String hash = genesis.proofOfWork(genesis.getDifficulty());
        chainHash = hash;//setting chain hash
        blocks.add(genesis); //adding genesis block
    }
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet BlockChainService</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet BlockChainService at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       
        String result = "";
        
        // fetching name from url
        String name = (request.getPathInfo()).substring(1);
       
        Boolean valid = false;
        
        // for verify
        if(name.equals("verify")){
            try {
                valid = isChainValid();
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(BlockChainService.class.getName()).log(Level.SEVERE, null, ex);
            }
             if(valid == false) {
            // no variable name found in map
                response.setStatus(401);
            return;    
        }
        
            // Things went well so set the HTTP response code to 200 OK
            response.setStatus(200);
            // tell the client the type of the response
            response.setContentType("text/plain;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("true");   
    }
        // for viewing
        else if(name.equals("view")){
            String viewString = jsonToString();
            if(viewString == null || viewString.equals("")){
                response.setStatus(401);
                return;
            }
            response.setStatus(200);
            // tell the client the type of the response
            response.setContentType("text/plain;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println(viewString);   
             
        }
        
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
       try {
           
           // To look at what the client accepts examine request.getHeader("Accept")
           // We are not using the accept header here.
           
           // Read what the client has placed in the POST data area
           BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
           String data = br.readLine();
           String decodeURL=URLDecoder.decode( data, "UTF-8" );
           String[] params = decodeURL.split("&");
           
           // fetching difficulty and data
           String difficulty = params[0].split("=")[1];
           String dataToAdd = params[1].split("=")[1];
           
           
           Boolean add = addBlock(Integer.parseInt(difficulty),dataToAdd);
           // if not added then return status 401
           if(add == false){
               response.setStatus(401);
               return;
           }
           // setting status 200 if everything is OK
           response.setStatus(200);
           // tell the client the type of the response
           response.setContentType("text/plain;charset=UTF-8");
           PrintWriter out = response.getWriter(); 
           out.println(add);
       } catch (NoSuchAlgorithmException ex) {
           Logger.getLogger(BlockChainService.class.getName()).log(Level.SEVERE, null, ex);
       }
       
    }

   
    
    public Boolean addBlock( int difficulty, String data) throws NoSuchAlgorithmException {
        
        
        String [] dataArray = data.split("#");
        String blockData = dataArray[0]; // Fetching data
        
        
        BigInteger signature = new BigInteger(dataArray[1]); // fetching signature
        
        // decrypting 
        BigInteger e = new BigInteger("65537");
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        BigInteger decrypt = signature.modPow(e, n); 
        
        
        // hashing the data using SHA-256
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        byte[] digest = m.digest(blockData.getBytes(StandardCharsets.UTF_8));
        
        
        
        // Adding 0 in the most significant byte
        byte [] digest1 = new byte[digest.length+1];
        digest1[0]=0;
        
        int i=1;
        for(byte b:digest){
            digest1[i]=b;
            i++;
        }
        
         BigInteger bigIntegerData = new BigInteger(digest1);
         
         // checking if signature is right
         if(bigIntegerData.equals(decrypt)){
               int index = blocks.size();

               Block newBlock = new Block((index),new Timestamp(System.currentTimeMillis()), data,difficulty);
               newBlock.setPreviousHash(chainHash);
               String hash = newBlock.proofOfWork(newBlock.getDifficulty());
               chainHash = hash;//setting chain hash
               blocks.add(newBlock); //adding new block
         }else{
             return false;
         }
        
     return true;
    }
    
    
    public String jsonToString() {
       StringBuilder result = new StringBuilder();
       String NEW_LINE = System.getProperty("line.separator");
       result.append("{\"chain\" :" + "[ {");
       
       for(Block b: blocks){
            result.append(b.toString());
            result.append(",\n");
       }
       result.append("],\"chainHash\":\""+chainHash+"\"}");
       return result.toString();
    }
    
     public Boolean isChainValid() throws NoSuchAlgorithmException {
         if(blocks.size()==1){
            
            int difficulty = blocks.get(0).getDifficulty();
            String hash = blocks.get(0).calculateHash();
            char c ='0';
            String diff="";
            int i=0;
            while(i<difficulty){
                
                diff = diff+c;
                i++;
            }
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking chain hash
                if(hash.equals(chainHash)){
                    return true;
            }
            }
            
            // index will be 0 as only one block
            System.out.println("Improper hash on node "+ 0 +" Does not begin with "+difficulty);
            return false;
            
        }
        else{
            int flag=0;
            int corruptedIndex =0;
            for(int i=0;i<blocks.size()-1;i++){
                Block b = blocks.get(i);
                String hash = b.calculateHash();
                int difficulty = b.getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
            
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking previous hash of next block
                String nextPrevHash = blocks.get(i+1).previousHash;
                    if(hash.equals(nextPrevHash)){
                    
                }
                    else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
                    }
            }else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
            }
                    
                
            }
           if(flag==1){
                       
               return false;
           } else{
               
               int difficulty = blocks.get(blocks.size()-1).getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
               // checking for last block
               String lastHash = blocks.get(blocks.size()-1).calculateHash();
               if(lastHash.equals(chainHash)){
                
                
            
            //Checking number of leading number of zeroes
                    if(lastHash.substring(0, difficulty).equals(diff)){
                        return true;
                    }
                    else{
                        System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+diff);
                        return false;
                    }
                   
                }
               else{
                   System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+ diff);
                   return false;
               }
              
           }
        }
    }

}
