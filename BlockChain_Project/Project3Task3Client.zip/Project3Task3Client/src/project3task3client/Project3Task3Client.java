/*
 * 
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is client for  REST architecture. The client makes a HTTP request to block chain API on server
 * The transaction data is signed using RSA keys, SHA-256 has been used for hashing the data
 * the client can only view, verify, add the block in a block chain
 */
package project3task3client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


// A simple class to wrap a result.
class Result {
    String value;

    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
}
public class Project3Task3Client {

   
    public static void main(String[] args) throws NoSuchAlgorithmException {
         Scanner sc = new Scanner(System.in);
     
     int input = 0;
     int countBlock = 1;
     do{
    // options to select
     System.out.println("Menu for Block Chain:");
     System.out.println("1. Add a transaction to the blockchain.");
     System.out.println("2. Verify the blockchain.");
     System.out.println("3. View the blockchain.");
     System.out.println("4. Exit.");
     input =sc.nextInt();
     if(input==1){
        System.out.println("Enter difficulty");
        int difficulty = sc.nextInt();
        
        sc.nextLine();
        System.out.println("Enter Transaction");
        String data = sc.nextLine();
        
        Long startTime = System.currentTimeMillis();
        
        // encrypting using SHA-256
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        byte[] digest = m.digest(data.getBytes(StandardCharsets.UTF_8));
       
        
        byte [] digest1 = new byte[digest.length+1];
        digest1[0]=0;
        
        int i=1;
        for(byte b:digest){
            digest1[i]=b;
            i++;
        }
        
        BigInteger bigIntegerData = new BigInteger(digest1);
        //signing using RSA keys
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
                        
        BigInteger encryptedData = bigIntegerData.modPow(d, n);
        
        // concatinating data and signature
        boolean add = addBlock(difficulty, (data+"#"+encryptedData));
        if(add==true){
        Long stopTime = System.currentTimeMillis();
        
        System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
        }else{// if signature is wrong
            System.out.println("Wrong signature provided");
        }
        
         
     }
     
     else if(input==2){
         System.out.println("Verifying");
         Long startTime = System.currentTimeMillis();
         System.out.println("Chain Verification:"+isChainValid());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
     }
     
     else if(input==3){
          Long startTime = System.currentTimeMillis();
         System.out.println("View the block chain");
         System.out.println(jsonToString());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime)+ " milliseconds");
     }
     
     }while(input!=4);
    }
    
    public static boolean addBlock(int difficulty, String data) {
        // Using POST, if status 200 means OK
        
        if(doPost(difficulty,data) == 200) {
            return true;
        }
        return false;
 }
    
    public static String isChainValid() {
        // GET request to check if chain is valid
        Result r = new Result();
        int status = 0;
        if((status = doGet("verify",r)) != 200) return "Error from server "+ status;
        return r.getValue();
      
 }
    
    
    public static String jsonToString() {
        // GET request to get the string JSON string format
        Result r = new Result();
        int status = 0;
        if((status = doGet("view",r)) != 200) return "Error from server "+ status;
        return r.getValue();
 }


    





 public static int doGet(String name, Result r) {
      
         r.setValue("");
         String response = "";
         HttpURLConnection conn;
         int status = 0;
         
         try {  
                
                // pass the name on the URL line
		URL url = new URL("http://localhost:8080/Project3Task3Server/BlockChainService" + "//"+name);
		conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
                // tell the server what format we want back
		conn.setRequestProperty("Accept", "text/plain");
 	
                // wait for response
                status = conn.getResponseCode();
               
                // If things went poorly, don't try to read any response, just return.
		if (status != 200) {
                    // not using msg
                    String msg = conn.getResponseMessage();
                    return conn.getResponseCode();
                }
                String output = "";
                // Reading the response
                BufferedReader br = new BufferedReader(new InputStreamReader(
			(conn.getInputStream())));
 		
		while ((output = br.readLine()) != null) {
			response += output + "\n";
         
		}
 
		conn.disconnect();
 
	    } 
                catch (MalformedURLException e) {
		   e.printStackTrace();
	    }   catch (IOException e) {
		   e.printStackTrace();
	    }
            
         // return value from server 
         // set the response object
         r.setValue(response);
         // return HTTP status to caller
         return status;
    } 
 
 
  public static int doPost(int difficulty, String data) {
          
        int status = 0;
        String output;
        
        try {  
                // Make call to a particular URL
		URL url = new URL("http://localhost:8080/Project3Task3Server/BlockChainService");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		
                // set request method to POST 
                conn.setRequestMethod("POST");
		conn.setDoOutput(true);
                
                //setting parameters
                Map<String, String> parameters = new HashMap<>();
                parameters.put("difficulty", Integer.toString(difficulty));
                parameters.put("data",data);
                
                // write to POST data area
                conn.setDoOutput(true);
                OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
                
                
                // using URL encode to encode parameter
                String urlParameters ="difficulty=" + URLEncoder.encode(Integer.toString(difficulty), "UTF-8") +"&data=" + URLEncoder.encode(data, "UTF-8");
                out.write(urlParameters.toString());
                out.close();
                
                // get HTTP response code sent by server
                status = conn.getResponseCode();
                
                //close the connection
		conn.disconnect();
	    } 
            // handle exceptions
            catch (MalformedURLException e) {
		      e.printStackTrace();        
            } 
            catch (IOException e) {
		      e.printStackTrace();
	    }
       
         
            return status;
    }
  
  
}
