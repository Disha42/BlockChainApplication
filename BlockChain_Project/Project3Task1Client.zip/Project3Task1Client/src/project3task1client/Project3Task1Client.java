/*
 * 
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This is Client side of code of block chain, It uses SOAP . The client makes a SOAP request to block chain API on server
 * The transaction data is signed using RSA keys, SHA-256 has been used for hashing the data
 * the client can only view, verify, add the block in a block chain
 */
package project3task1client;

import com.blockchain.NoSuchAlgorithmException_Exception;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class Project3Task1Client {

    
    public static void main(String[] args) throws NoSuchAlgorithmException_Exception, NoSuchAlgorithmException {
        Scanner sc = new Scanner(System.in);
     
     int input = 0;
     int countBlock = 1;
     
     // Menu for the users
     do{
    
     System.out.println("Menu for Block Chain:");
     System.out.println("1. Add a transaction to the blockchain.");
     System.out.println("2. Verify the blockchain.");
     System.out.println("3. View the blockchain.");
     System.out.println("4. Exit.");
     input =sc.nextInt();
     if(input==1){
        System.out.println("Enter difficulty");
        int difficulty = sc.nextInt();
        
        sc.nextLine();
        System.out.println("Enter Transaction");
        String data = sc.nextLine();
        
        Long startTime = System.currentTimeMillis();
        
        // encrypting using SHA-256
        MessageDigest m = MessageDigest.getInstance("SHA-256");
        byte[] digest = m.digest(data.getBytes(StandardCharsets.UTF_8));
       
        
        byte [] digest1 = new byte[digest.length+1];
        digest1[0]=0;
        
        int i=1;
        for(byte b:digest){
            digest1[i]=b;
            i++;
        }
        
        BigInteger bigIntegerData = new BigInteger(digest1);
        //signing using RSA keys
        BigInteger n = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
        BigInteger d = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
                        
        BigInteger encryptedData = bigIntegerData.modPow(d, n);
        
        // concatnating data and signature
        boolean add = addBlock(difficulty, (data+"#"+encryptedData));
        if(add==true){
        Long stopTime = System.currentTimeMillis();
        
        System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
        }else{// if signature is wrong
            System.out.println("Wrong signature provided");
        }
        
         
     }
     
     else if(input==2){
         System.out.println("Verifying");
         Long startTime = System.currentTimeMillis();
         System.out.println("Chain Verification:"+isChainValid());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
     }
     
     else if(input==3){
          Long startTime = System.currentTimeMillis();
         System.out.println("View the block chain");
         System.out.println(jsonToString());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime)+ " milliseconds");
     }
     
     }while(input!=4);
     
    }

    private static Boolean addBlock(int difficulty, java.lang.String data) throws NoSuchAlgorithmException_Exception {
        com.blockchain.BlockChainService_Service service = new com.blockchain.BlockChainService_Service();
        com.blockchain.BlockChainService port = service.getBlockChainServicePort();
        return port.addBlock(difficulty, data);
    }

    private static Boolean isChainValid() throws NoSuchAlgorithmException_Exception {
        com.blockchain.BlockChainService_Service service = new com.blockchain.BlockChainService_Service();
        com.blockchain.BlockChainService port = service.getBlockChainServicePort();
        return port.isChainValid();
    }

    private static String jsonToString() {
        com.blockchain.BlockChainService_Service service = new com.blockchain.BlockChainService_Service();
        com.blockchain.BlockChainService port = service.getBlockChainServicePort();
        return port.jsonToString();
    }

   



   
    
}
