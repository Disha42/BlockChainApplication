
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;


/*
 * This class represents block chain
 * @author Disha Nathani
 * Last modified: March 11,2018
 * This uses block class, user can add a new block, verify if the block chain is valid, corrupt the block chain and repair
 * 
 */


public class BlockChain {
    
    ArrayList<Block> blocks; // arraylist to hold the blocks
    String chainHash; // the hash of the last block
    
    
   public BlockChain(){
        this.blocks = new ArrayList();
        this.chainHash ="";
    }
   
   public Timestamp getTime(){
       
       return new Timestamp(System.currentTimeMillis());
   }
   
   public Block getLatestBlock(){
       return blocks.get(blocks.size()-1);
   }
   
   // adding the block to the block chain
  
   public void addBlock(Block newBlock){
       String hash = newBlock.proofOfWork(newBlock.getDifficulty());
       chainHash = hash;//setting chain hash
       blocks.add(newBlock); //adding new block
   }
    
   //To string for block chain
   @Override
   public String toString(){
       
       StringBuilder result = new StringBuilder();
       String NEW_LINE = System.getProperty("line.separator");
       result.append("{\"chain\" :" + "[ {");
       
       // getting all the blocks to string
       for(Block b: blocks){
            result.append(b.toString());
            result.append(","+ NEW_LINE);
       }
       result.append("],\"chainHash\":\""+chainHash+"\"}");
       return result.toString();
   }
   
   // to check if the chain is valid
   public boolean isChainValid() throws NoSuchAlgorithmException{
       
       // if there is only one element in the block chain
        if(blocks.size()==1){
            
            int difficulty = blocks.get(0).getDifficulty();
            String hash = blocks.get(0).calculateHash();
            char c ='0';
            String diff="";
            int i=0;
            
            // generating 0 whose length is equal to difficulty
            while(i<difficulty){
                
                diff = diff+c;
                i++;
            }
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking chain hash
                if(hash.equals(chainHash)){
                    return true;
            }
            }
            
            // index will be 0 as only one block
            System.out.println("Improper hash on node "+ 0 +" Does not begin with "+difficulty);
            return false;
            
        }
        // for block chain of length>1
        else{
            int flag=0;
            int corruptedIndex =0;
            for(int i=0;i<blocks.size()-1;i++){
                Block b = blocks.get(i);
                String hash = b.calculateHash();
                int difficulty = b.getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
            
            //Checking number of leading number of zeroes
            if(hash.substring(0, difficulty).equals(diff)){
                // checking previous hash of next block
                String nextPrevHash = blocks.get(i+1).previousHash;
                    if(hash.equals(nextPrevHash)){
                    
                }
                    else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
                    }
            }else{
                        flag=1;
                        System.out.println("Improper hash on node "+ i +" Does not begin with "+diff);
                        break;
            }
                    
                
            }
           if(flag==1){
               return false;
           } else{
               
               int difficulty = blocks.get(blocks.size()-1).getDifficulty();
                char c ='0';
                String diff="";
                int j=0;
                
                while(j<difficulty){
                    diff = diff+c;
                    j++;
                }
                
               // checking for last block
               String lastHash = blocks.get(blocks.size()-1).calculateHash();
               if(lastHash.equals(chainHash)){
                
                
            
            //Checking number of leading number of zeroes
                    if(lastHash.substring(0, difficulty).equals(diff)){
                        return true;
                    }
                    else{
                        System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+diff);
                        return false;
                    }
                   
                }
               else{
                   System.out.println("Improper hash on node "+ (blocks.size()-1) +" Does not begin with "+ diff);
                   return false;
               }
              
           }
        }
       
   }
   
  // To repair the corruptedd block chain 
 public void repairChain() throws NoSuchAlgorithmException{
    
     for(int i=0;i<blocks.size()-1;i++){
         Block b = blocks.get(i);
         String hash = b.calculateHash();
         
         String nextPrevHash = blocks.get(i+1).previousHash;
                    if(hash.equals(nextPrevHash)){
                    
                }
                    else{// previous hash of next block is not equal to current hash
                        //There is a corrupt block
                        
                        
                        for(int j=i;j<blocks.size()-1;j++){
                            Block b1 = blocks.get(j);
                            String newHash = b1.proofOfWork(b1.getDifficulty());
                            blocks.get(j+1).previousHash = newHash;
                            
                        }
                        
                        
                    break;
                    }
             
     }
     // checking for the last block
     Block lastBlock = blocks.get(blocks.size()-1);
     String lastHash = lastBlock.calculateHash();
     if(lastHash.equals(chainHash)){
         
     }else{
         String newHash = lastBlock.proofOfWork(lastBlock.getDifficulty());
         chainHash = newHash;
     }
     
    
 }
 
 public static void main(java.lang.String[] args) throws NoSuchAlgorithmException{
     
     BlockChain blockChain = new BlockChain();
     
     // adding the genesis block
     Block genesis = new Block(0, new Timestamp(System.currentTimeMillis()) ,"Genesis",2);
     genesis.setPreviousHash("");
     blockChain.addBlock(genesis);
     
     
     
     Scanner sc = new Scanner(System.in);
     
     int input = 0;
     int countBlock = 1;
     
     // the menu option
     do{
    
     System.out.println("Menu for Block Chain:");
     System.out.println("1. Add a transaction to the blockchain.");
     System.out.println("2. Verify the blockchain.");
     System.out.println("3. View the blockchain.");
     System.out.println("4. Corrupt the chain.");
     System.out.println("5. Hide the corruption by repairing the chain.");
     System.out.println("6. Exit.");
     input =sc.nextInt();
     if(input==1){
        System.out.println("Enter difficulty");
        int difficulty = sc.nextInt();
        
        sc.nextLine();
        System.out.println("Enter Transaction");
        String data = sc.nextLine();
        
        Long startTime = System.currentTimeMillis();
        Block newBlock = new Block(countBlock,blockChain.getTime(), data,difficulty);
        newBlock.setPreviousHash(blockChain.chainHash);
        countBlock = countBlock+1;
        
        blockChain.addBlock(newBlock);
        Long stopTime = System.currentTimeMillis();
        
        System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
         
     }
     
     else if(input==2){
         System.out.println("Verifying");
         Long startTime = System.currentTimeMillis();
         System.out.println("Chain Verification:"+blockChain.isChainValid());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime) + " milliseconds");
     }
     
     else if(input==3){
         Long startTime = System.currentTimeMillis();
         System.out.println("View the block chain");
         System.out.println(blockChain.toString());
         Long stopTime = System.currentTimeMillis();
         System.out.println("Total executuion time to add this block "+ (stopTime-startTime)+ " milliseconds");
     }
     else if(input==4){
         System.out.println("Corrupt the Blockchain");
         System.out.println("Enter block to corrrupt");
         int blockToCorrupt = sc.nextInt();
         sc.nextLine();
         System.out.println("Enter new data for the block");
         String data = sc.nextLine();
         blockChain.blocks.get(blockToCorrupt).setData(data);
         System.out.println("Block "+blockToCorrupt+" now holds "+ blockChain.blocks.get(blockToCorrupt).getData());
         
     }
     else if(input==5){
         System.out.println("Repair the block chain");
         blockChain.repairChain();
         System.out.println("Repair complete");
     }
     
     }while(input!=6);
     
     
     
         
     
     







             
     
 }
}
